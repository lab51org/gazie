Api for sincro Gazie
--------------------

Questo modulo è stato creato per
ottenere clienti, prodotti e vendite
tramite api.

Una volta ottenute le informazioni si può
sincronizzarle con un altro applicativo.

Uninstall
---------

Per una completa rimozione delle api
cancellare i files nelle cartelle

catalog/controller/sync
catalog/model/sync

